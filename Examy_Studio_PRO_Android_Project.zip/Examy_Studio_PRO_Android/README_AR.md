# Examy Studio PRO — مشروع Android

هذا مشروع Android Studio يغلّف أحدث نسخة HTML محلياً داخل WebView.

## البناء
1. افتح Android Studio.
2. اختر Open ثم مجلد `Examy_Studio_PRO_Android`.
3. انتظر Gradle Sync (يلزم اتصال إنترنت أول مرة لتنزيل Android Gradle Plugin ومكونات SDK).
4. من Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5. ستجد الملف في `app/build/outputs/apk/debug/app-debug.apk`.

## ما يتضمنه
- صفحة HTML داخل `app/src/main/assets/index.html` وتعمل محلياً.
- JavaScript وDOM Storage مفعّلان لحفظ بيانات التطبيق.
- لا توجد صلاحية INTERNET في Manifest.
- توجيه `window.print()` إلى خدمة طباعة Android مع ورق A4.
- الحد الأدنى Android 6.0 (API 23).

## ملاحظات قبل التوزيع
- هذا مشروع مصدر جاهز للبناء، وليس APK مبنياً أو موقعاً رقمياً.
- اختبر حفظ البيانات والطباعة على هاتفك قبل الاعتماد عليه.
- خطوط Google في ملف HTML تتطلب اتصالاً لتنزيلها؛ عند عدم توفر الإنترنت سيستخدم المتصفح الخطوط البديلة المتاحة محلياً.
- إعداد هوامش الطباعة داخل الصفحة يظل خاضعاً أيضاً لحدود خدمة الطباعة والطابعة.
- لا ترفع التطبيق إلى المتجر قبل إعداد أيقونة، سياسة خصوصية، وتوقيع Release.
